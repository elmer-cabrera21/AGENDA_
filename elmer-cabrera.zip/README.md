# Agenda Personal de Contactos con Autenticación en PHP

## 📝 Descripción del Proyecto
Aplicación web desarrollada en PHP y MySQL que permite a los usuarios registrarse, iniciar sesión y gestionar una agenda personal de contactos. El sistema garantiza la seguridad mediante la encriptación de contraseñas y el uso de sesiones, asegurando que cada usuario pueda visualizar, editar y eliminar **únicamente sus propios contactos**.

## 🛠️ Tecnologías Utilizadas
* **PHP** (Lógica del servidor y manejo de sesiones)
* **MySQL** (Base de datos relacional)
* **PDO** (PHP Data Objects para consultas seguras y prevención de inyección SQL)
* **HTML5 y CSS3** (Estructura y diseño de la interfaz)
* **XAMPP** (Servidor local Apache)

## ⚙️ Funcionalidades Principales
* **Registro de usuarios:** Validación de correo electrónico único y encriptación de contraseña con `password_hash()`.
* **Inicio de sesión:** Verificación de credenciales con `password_verify()` y creación de variables de sesión (`$_SESSION`).
* **Panel Principal:** Página protegida que muestra el nombre del usuario y su lista de contactos.
* **CRUD de Contactos:** Crear, Leer, Actualizar (Editar) y Eliminar contactos.
* **Seguridad:** Restricción de acceso a páginas si no hay sesión activa y filtrado de datos por ID de usuario para evitar que un usuario vea contactos ajenos manipulando la URL.

## 📋 Requisitos para su Ejecución
* Tener instalado un servidor local como **XAMPP**,
* Un navegador web actualizado (Chrome, Edge, Firefox).
* PHP 7.4 o superior.

## 🚀 Pasos para Instalar y Ejecutar
1. **Clonar o descargar** este repositorio y colocar la carpeta `agenda` dentro del directorio `htdocs` de tu servidor local (ej. `C:\xampp\htdocs\agenda`).
2. Abrir el panel de control de **XAMPP** e iniciar los módulos de **Apache** y **MySQL**.
3. Abrir **phpMyAdmin** en el navegador (`http://localhost/phpmyadmin`).
4. Crear una base de datos llamada **`agenda_contactos`** e importar el archivo **`database.sql`** (incluido en este repositorio) para generar las tablas automáticamente.
5. Verificar el archivo **`config.php`**. Si tu MySQL tiene contraseña, agrégala en la variable `$password`. (Por defecto en XAMPP es `root` y contraseña vacía `""`).
6. Abrir en el navegador la siguiente URL para empezar:
   👉 **`http://localhost/agenda/registro.php`**

## 📂 Estructura de la Base de Datos
* **Tabla `usuarios`:** Guarda el id, nombre, correo, contraseña (encriptada) y fecha de registro.
* **Tabla `contactos`:** Guarda el id, id_usuario (llave foránea), nombre, teléfono, correo y ciudad.

## 👨‍💻 Autor
**Elmer Fernando Cabrera Sánchez**
*Desarrollado como proyecto académico para la materia de Desarrollo Web.*